		<div id="sidebar">
		
			<?php
			if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Main Sidebar')): 
			endif;
			?>
		
		</div><!-- END SIDEBAR -->